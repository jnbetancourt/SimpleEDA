#' Title
#'
#' @param data_frame 
#' @param first_column_name 
#' @param second_column_name 
#'
#' @return
#'
#' @examples
factorVarCorrelation <- function(data_frame, first_column_name, second_column_name) {
  #TODO: Contingency tables w/ Chi-Square and Fisher's Exact Test
  
  # To access first column, instead of using "data_frame$first_column_name", use:
  # data_frame[, first_column_name]
  
}