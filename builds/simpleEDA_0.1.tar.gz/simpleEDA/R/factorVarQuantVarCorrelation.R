#' Title
#'
#' @param data_frame 
#' @param factor_column_name 
#' @param quant_column_name 
#'
#' @return
#'
#' @examples
factorVarQuantVarCorrelation <- function(data_frame, factor_column_name, quant_column_name) {
  #TODO: Conditional Density Plot
  #TODO: Box plots by factor column
  #TODO: Cohen's D Test
  #TODO: Shapiro-Wilk Test by factor column
  #TODO: Anova t-test
  #TODO: Kruskal-Wallis test
  
  # To access first column, instead of using "data_frame$first_column_name", use:
  # data_frame[, first_column_name]
}