## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(simpleEDA)

## -----------------------------------------------------------------------------
data(mtcars)

mtcars$am <- factor(mtcars$am, labels = c('automatic', 'manual'))
mtcars$vs <- factor(mtcars$vs, labels = c('v-shaped', 'straight'))
head(mtcars)

## -----------------------------------------------------------------------------
simpleEDA(data_frame = mtcars, response_column_name = 'mpg',
          predictor_column_names = c('hp'))

## -----------------------------------------------------------------------------
simpleEDA(data_frame = mtcars, response_column_name = 'mpg',
          predictor_column_names = c('am'))

## -----------------------------------------------------------------------------
simpleEDA(data_frame = mtcars, response_column_name = 'mpg',
          predictor_column_names = c('hp', 'wt', 'vs', 'am'))

